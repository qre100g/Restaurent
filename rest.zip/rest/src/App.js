import logo from './logo.svg';
import './App.css';
import Main from './Components/registration';

function App() {
  return (
    <div >
      <Main />
    </div>
  );
}

export default App;
