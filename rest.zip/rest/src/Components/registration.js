import { useState } from 'react';
import '../Styles/login.css';

function RegisterDone () {
    return(<div className='loginContainer'>
        <h3>You have been registered Successfully! <br/> Login to Continue </h3>

    </div>)
}

function Register () {
    const [registrationDone, setRegistration] = useState(false)
    return (<>
        {registrationDone === false ? 
            <>
            <h3>Registration</h3>
            <div className='loginContainer'>
                <div className='item'>
                    <span>Name:</span>
                    <input/>
                </div>
                <div className='item'>
                    <span>Email:</span>
                    <input type= 'email'/>
                </div>

                <h3 className='typeOfConsumer'>
                    <input type={'radio'} 
                        value={'Customer'}
                        name='Consumer'
                    />
                    <label>
                        Customer
                    </label>
                    <input id='res' name='Consumer' type={'radio'} value={'Restaurent'}/>
                    <label>Restaurent</label>
                </h3>
                
                <div className='item'>
                    <span>Phone No:</span>
                    <input type= 'number' />
                </div>
                <div className='item' >
                    <span>Password:</span>
                    <input type= 'password' />
                </div>
                <div className='item'>
                    <span>Re-enter Password:</span>
                    <input type= 'password' />
                </div>
    
                <button className='signin'
                    onClick={() => {
                        setRegistration(true);
                    }}
                >Register</button>
            </div>
            </>
            : <RegisterDone />
        }
    </>)
}

function Login (props) {
    const name = '420k';
    const pass_word = '#420';
    
    const [userName, setUserName] = useState('');
    const [password, setPassword] = useState('');
    const [detailsEntered, setEntered] = useState(false);
    return(<div>
        <h3>Login</h3>
            <h3 className='typeOfConsumer'>
                <input type={'radio'} 
                    value={'Customer'}
                    name='Consumer'
                />
                <label>
                    Customer
                </label>
                <input id='res' name='Consumer' type={'radio'} value={'Restaurent'}/>
                <label>Restaurent</label>
                <input id='admin' name='Consumer' type={'radio'} value={'Admin'}/>
                <label>Admin</label>
            </h3>

            <div className='loginContainer'>
                <div className='item'>
                    <span>UserName</span>
                    <input value={userName}
                        onChange={(e) => {
                            setUserName(e.target.value);
                        }}
                    />
                </div>
                <div className='item'>
                    <span>Password</span>
                    <input type={'password'} value={password} 
                        onChange={(e) => {
                            console.log(password);
                            setPassword(e.target.value);
                        }}
                    />
                </div>
            </div>
            {detailsEntered === true ? <h3>
                Invalid details
            </h3> :<></>}

            <button className='signin'
                onClick={() => {
                    if(userName === name && password === pass_word) {
                        props.setdetails(true);
                    }
                    else {
                        setEntered(true);
                    }
                }}
            >Signin</button>

            <button className='signin'
                onClick={() => {

                    props.setregister(true);
                }}
            >NewUser Register</button>
    </div>)
}


function Main () {
    const [detailsValid, setDetails] = useState(false);
    
    const [register, setRegister] = useState(false);

    //total Component
    return(<>{detailsValid === false ?
        <div className='container'>
            <div className='header'>
                <h3 className='headLine'>Food Catering System</h3>
            </div>
            {register === true ? <Register /> : <Login setdetails = {setDetails} setregister = {setRegister}/>}
            
        </div>
        : <h1>After Login</h1>
    }</>)
}

export default Main;
export {Register, Login}